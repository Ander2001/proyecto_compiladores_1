package PAQUETEANALIZAR;
//Creamos nuestro método con todos nuestros posibles datos a encontrar dentro del archivo txt
public enum Ejecucion {
  CREAR_CLIENTE("CREAR_CLIENTE",
      5,
      new String[] { "Integer", "String", "String", "String", "Date" }),
  CREAR_CUENTA("CREAR_CUENTA",
      5,
      new String[] { "Integer", "String", "Integer", "Double", "Boolean" }),
  DEPOSITO("DEPOSITO",
      3,
      new String[] { "Integer", "Double", "Date" }),
  RETIRO("RETIRO",
      3,
      new String[] { "Integer", "Double", "Date" }),
  ELIMINAR_CLIENTE("ELIMINAR_CLIENTE",
      1,
      new String[] { "Integer"}),
  ELIMINAR_CUENTA("ELIMINAR_CUENTA",
      1,
      new String[] { "Integer"}),
  ERROR("Error",
      0,
      new String[] {});
//Declaración de atributos privados
  private String nombreFuncion;
  private int noParametros;
  private String[] tipoParametros;
//Declaración de clases privados
  private Ejecucion(String nombreFuncion, int noParametros, String[] tipoParametros) {
    this.nombreFuncion = nombreFuncion;
    this.noParametros = noParametros;
    this.tipoParametros = tipoParametros;
  }
//Creación de constructores
  public String getNombreFuncion() {
    return nombreFuncion;
  }

  public int getNoParametros() {
    return noParametros;
  }

  public String[] getTipoParametros() {
    return tipoParametros;
  }
//Creación de método para la ejecución de nuestro analizador léxico del archivo txt
  public static Ejecucion getAccion(String accionS) {
    for (Ejecucion value : Ejecucion.values()) {
      if (value.nombreFuncion.equals(accionS)) {
        return value;
      }
    }

    return ERROR;
  }
}