package MICOOPEGUAYACAN;

import java.util.ArrayList;
import java.time.LocalDate;
import java.util.HashMap;
//Declaramos nuestra clase para llevar un control de las cuentas de nuestros asociados
public class MICOOPEGuayacan {
  private HashMap<Integer, AhorroCorriente> cuentas = new HashMap<>();
  private HashMap<Integer, AhorroCorriente> cuentasS = new HashMap<>();
  private HashMap<Integer, Asociado> clientes = new HashMap<>();
  private int clientasCreados = 0;
  private int cuentasCreadas = 0;
  private int clientesEliminados = 0;
  private int cuentasEliminadas = 0;
  private int errores = 0;
  private int depositos = 0;
  private int retiros = 0;
  //Hacemos público nuestro método para crear cuenta y validar que no haya duplicidad de cuentas
  public void crearCuenta(Object[] params) {
    if (existeCuenta((int)params[0])) {
      System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.out.println("La cuenta que se desea crear ya existe");
      System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.out.println("\n");
      return;
    }
    //Por medio de la presente validación verificamos si el asociado posee ya cuenta con MICOOPE Guayacán
    AhorroCorriente ctaahorro = new AhorroCorriente((int) params[0], (String) params[1], (int) params[2], (Double) params[3],
        (Boolean) params[4]);
    cuentas.put((int)params[0], ctaahorro);
    cuentasS.put((int)params[0], ctaahorro);
    cuentasCreadas++;
  }
//Método para crear asociado
  public void crearCliente(Object[] params) {
    if (existeCliente((int)params[0])) {
    	System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.out.println("No es posible ingresar a la persona, ya existe un asociado con los mismos datos");
      System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.out.println("\n");
      return;
    }
    Asociado asociado = new Asociado((int) params[0], (String) params[1], (String) params[2], (String) params[3],
        (LocalDate) params[4]);
    clientes.put((int)params[0], asociado);
    clientasCreados++;
  }
//Método para validar los depósitos
  public void depositar(Object[] params) {
    if (!existeCuenta((int)params[0])) {
    	System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.out.println("No es posible completar la transacción, cuenta inexistente");
      System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.out.println("\n");
      return;
    }

    AhorroCorriente c = cuentas.get((int)params[0]);
    if(c.getFehcaDeposito().isAfter((LocalDate)params[2])){
    	System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.out.println("Fecha de deposito erronea, no se puede depositar en fecha anterior a la actual");
      System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.out.println("\n");
      return;
    }
    Double saldoEncuenta = c.getDinero();
    saldoEncuenta += (Double)params[1];
    c.setFehcaDeposito((LocalDate)params[2]);
    c.setDinero(saldoEncuenta);
    cuentas.put(c.getCodigoCuenta(), c);
    cuentasS.put(c.getCodigoCuenta(), c);
    depositos++;
  }
//Método para verificar la existencia de la cuenta
  public void retirar(Object[] params) {
    if (!existeCuenta((int)params[0])) {
      System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.out.println("Lo sentimos, la cuenta ingresada no existe");
      System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.out.println("\n");
      return;
    }

    AhorroCorriente c = cuentas.get((int)params[0]);
    if(c.getFehcaDeposito().isAfter((LocalDate)params[2])){
    	System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.out.println("Fecha de retiro inválida");
      System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.out.println("\n");
      return;
    }
    Double saldoEncuenta = c.getDinero();
    if(saldoEncuenta < (Double)params[1]){
    	System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.out.println("No puede realizar el retiro, asociado no posee saldo suficiente para el monto a retirar");
      System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.out.println("\n");
      return;
    }
    
    saldoEncuenta -= (Double)params[1];
    c.setFehcaDeposito((LocalDate)params[2]);
    c.setDinero(saldoEncuenta);

    cuentas.put(c.getCodigoCuenta(), c);
    cuentasS.put(c.getCodigoCuenta(), c);
    retiros++;
  }
//Método para eliminar cuenta
  public void eliminarCuenta(Object[] params) {
    if (!existeCuenta((int)params[0])) {
    	System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.out.println("Lo sentimos, la cuenta ingresada no existe");
      System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.out.println("\n");
      return;
    }
    AhorroCorriente c = cuentas.get((int)params[0]);
    if(c.getDinero() > 0){
    	System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.out.println("Cuenta no puede ser eliminada, posee saldo disponible en su cuenta");
      System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.out.println("\n");
      return;
    }
    cuentas.remove((int)params[0]);
    cuentasEliminadas++;
  }
//Método para eliminar cliente
  public void eliminarCliente(Object[] params) {
    if (!existeCliente((int)params[0])) {
    	System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.out.println("No es posible ingresar a la persona, ya existe un asociado con los mismos datos");
      System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.out.println("\n");
      return;
    }
    Asociado c = clientes.get((int)params[0]);
    if(noDeCuentasAsociadas(c.getCodigoCliente()) > 0){
    	System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.out.println("No es posible completar lo solicitado, posee cuentas de ahorro activas");
      System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.out.println("\n");
      return;
    }
    clientes.remove((int)params[0]);
    clientesEliminados++;
  }
//Se crea un contador de errores para ser almacenados
  public void error(){
    errores++;
  }
//Validamos existencia de la cuenta
  public boolean existeCuenta(int id) {
    return cuentas.get(id) != null;
  }
//Validamos existencia del asociado
  public boolean existeCliente(int id) {
    return clientes.get(id) != null;
  }
//Validamos cuentas asociadas al asociado
  private int noDeCuentasAsociadas(int idCliente){
    int sumSaldosCtas = 0;
    for(AhorroCorriente c : cuentas.values()){
      if(c.getCodigoCliente() == idCliente) sumSaldosCtas++;
    }
    return sumSaldosCtas;
  }
//Método para generar reportes 
  public void reporte(){
	  System.out.println("\n");
		System.out.println("------------------------------------------------");
		System.out.println("------------------------------------------------");
	    System.out.println("Total de asociados creados: " + clientasCreados);
	    System.out.println("------------------------------------------------");
	    System.out.println("------------------------------------------------");
	    System.out.println("Total de asociados eliminados: " + clientesEliminados);
	    System.out.println("------------------------------------------------");
	    System.out.println("------------------------------------------------");
	    System.out.println("Total de cuentas creadas: " + cuentasCreadas);
	    System.out.println("------------------------------------------------");
	    System.out.println("------------------------------------------------");
	    System.out.println("Total de cuentas eliminadas: " + cuentasEliminadas);
	    System.out.println("------------------------------------------------");;
	    System.out.println("------------------------------------------------");
	    System.out.println("Total de depositos realizados: " + depositos);
	    System.out.println("------------------------------------------------");
	    System.out.println("------------------------------------------------");
	    System.out.println("Total de retiros realizados: " + retiros);
	    System.out.println("------------------------------------------------");
	    System.out.println("------------------------------------------------");
	    System.out.println("\n");

    for(AhorroCorriente c : cuentasS.values()){
    	System.out.println("\n");
        System.out.println("------------------------------------------------------------------------------------------------------");
        System.out.println("Asociado con número de cuenta" + c.getCodigoCuenta() + " realizó" + c.getDepositos() + "depósitos.");
        System.out.println("------------------------------------------------------------------------------------------------------");
        System.out.println("------------------------------------------------------------------------------------------------------");
        System.out.println("Asociado con número de cuenta" + c.getCodigoCuenta() + " realizó" + c.getRetiros() + " retiros.");
        System.out.println("------------------------------------------------------------------------------------------------------");
        System.out.println("\n");

    }
    System.out.println("------------------------------------------------------------------------------------------------------");
    System.out.println("------------------------------------------------------------------------------------------------------");
    System.out.println("Total de retiros realizados: " + retiros);
    System.out.println("------------------------------------------------------------------------------------------------------");
    System.out.println("------------------------------------------------------------------------------------------------------");
    System.out.println("Total de errores encontrados: " + errores);
    System.out.println("------------------------------------------------------------------------------------------------------");
    System.out.println("------------------------------------------------------------------------------------------------------");
    System.out.println("\n");
    System.out.println("********************************************************************************************************");
    System.out.println("Total de errores en la presente compilación: " + errores);
    System.out.println("********************************************************************************************************");
    System.out.println("\n");
  }
}
