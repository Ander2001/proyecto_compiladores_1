package PAQUETEANALIZAR;
//Declaración de clase para llevar el control de transacciones
public class Transaccion {
  public Ejecucion accion;
  public Object[] parametros;
//Declaración de método para llevar el control de transacciones convinado a la transacción
  public Transaccion(Ejecucion accion, Object[] parametros) {
    this.accion = accion;
    this.parametros = parametros;
  }
}
