
package codigo;

import java.io.File;

/**
 *
 * @author Luis Herrera
 */

//Creamos un método el cual nos ayude a encontrar la función de Java JFlex
public class Principal {
    public static void main(String[] args) {
        String ruta = "C:/Users/lherr/OneDrive/Escritorio/JFlex";
        generarLexer(ruta);
    }
    
    //Por medio de la presente leemos el archivo por medio de la función principal de JFlex
    public static void generarLexer(String ruta){
        File archivo = new File(ruta);
        JFlex.Main.generate(archivo);
    }
}
