package MICOOPEGUAYACAN;

import java.time.LocalDate;
//En esta clase declaramos cada uno de los parámetros y atributos a utilizar
public class Asociado {
  
  private int codigoCliente;
  private String nombre;
  private String dirrecion;
  private String telefono;
  private LocalDate fechaNacimiento;

//Declaramos nuestro método Asociados como pública
  public Asociado(int codigoCliente, String nombre, String dirrecion, String telefono, LocalDate fechaNacimiento) {
    this.codigoCliente = codigoCliente;
    this.nombre = nombre;
    this.dirrecion = dirrecion;
    this.telefono = telefono;
    this.fechaNacimiento = fechaNacimiento;
  }
//Método para obtener el código del asociado
  public int getCodigoCliente() {
    return codigoCliente;
  }

  public void setCodigoCliente(int codigoCliente) {
    this.codigoCliente = codigoCliente;
  }
//Método para obtener el nombre del asociado
  public String getNombre() {
    return nombre;
  }
//Método para setear el nombre del asociado
  public void setNombre(String nombre) {
    this.nombre = nombre;
  }
//Método para obtener la dirección del asociado
  public String getDirrecion() {
    return dirrecion;
  }
//Método para setear la dirección del asociado
  public void setDirrecion(String dirrecion) {
    this.dirrecion = dirrecion;
  }
//Método para obtener el teléfono del asociado
  public String getTelefono() {
    return telefono;
  }
//Método para setear el teléfono del asociado
  public void setTelefono(String telefono) {
    this.telefono = telefono;
  }
//Método para obtener la fecha de nacimiento del asociado
  public LocalDate getFehcaNacimiento() {
    return fechaNacimiento;
  }
//Método para setear la fecha de nacimiento del asociado
  public void setFehcaNacimiento(LocalDate fehcaNacimiento) {
    this.fechaNacimiento = fehcaNacimiento;
  }
  
}
