
package codigo;

/**
 *
 * @author Luis Herrera
 */

//Declaramos nuestros tokens posibles a identificar
public enum Tokens {
    Reservadas,
    Igual,
    Suma,
    Resta,
    Multiplicacion,
    Division,
    Identificador,
    Numero,
    Separador,
    ERROR
}
