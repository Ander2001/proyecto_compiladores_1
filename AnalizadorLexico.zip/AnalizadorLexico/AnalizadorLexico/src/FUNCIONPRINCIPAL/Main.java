package FUNCIONPRINCIPAL;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import MICOOPEGUAYACAN.MICOOPEGuayacan;
import PAQUETEANALIZAR.*;
//Creamos nuestra función principal para correr nuestro programa
public class Main {
  public static void main(String[] args) {
//Por medio del try catch detectamos y controlamos una excepción generada por código en funcionamiento
    try {
      File myObj = new File("archivo.txt");
      Scanner myReader = new Scanner(myObj);

      ArrayList<Transaccion> transacciones = new ArrayList();
      AnErroresMICOOPE lexico = new AnErroresMICOOPE();
      
    //Mientras el analizados encuentre nuestro archivo, procedemos a nuestro for de transacciones
      while (myReader.hasNextLine()) {
        String fecha = myReader.nextLine();
        transacciones.add(lexico.analizarLinea(fecha));

      }
      myReader.close();
      MICOOPEGuayacan micoope = new MICOOPEGuayacan();

      for (Transaccion gestion : transacciones) {
        switch (gestion.accion) {
          case CREAR_CLIENTE:
            micoope.crearCliente(gestion.parametros);
            break;
          case CREAR_CUENTA:
            micoope.crearCuenta(gestion.parametros);
            break;
          case DEPOSITO:
            micoope.depositar(gestion.parametros);
            break;
          case ELIMINAR_CLIENTE:
            micoope.eliminarCliente(gestion.parametros);
            break;
          case ELIMINAR_CUENTA:
            micoope.eliminarCuenta(gestion.parametros);
            break;
          case ERROR:
            micoope.error();
            break;
          case RETIRO:
            micoope.retirar(gestion.parametros);
            break;
        }
      }
      micoope.reporte();

    } catch (FileNotFoundException e) {
    	System.out.println("Por favor verifique la ubicación del archivo, no fue encontrado :(");
      e.printStackTrace();
    }
  }
}