package MICOOPEGUAYACAN;

import java.time.LocalDate;

public class AhorroCorriente {
	//Declaramos nuestros atributos para la clase cuenta
  private int codigoCuenta;
  private String nombreCuenta;
  private int codigoCliente;
  private Double pisto;
  private Boolean quetzales;
  private LocalDate fechaDeposito;
  private int retiros = 0;
  private int depositos = 0;
  
//Volvemos pública nuestra clase así como la instanciación de las mismas
  public AhorroCorriente(int codigoCuenta, String nombreCuenta, int codigoCliente, Double pisto, Boolean quetzales) {
    this.codigoCuenta = codigoCuenta;
    this.nombreCuenta = nombreCuenta;
    this.codigoCliente = codigoCliente;
    this.pisto = pisto;
    this.quetzales = quetzales;
    this.fechaDeposito = LocalDate.of(1900, 1, 1);
  }
//Método para obtener el código de la cuenta
  public int getCodigoCuenta() {
    return codigoCuenta;
  }
//Método para setear el código de la cuenta
  public void setCodigoCuenta(int codigoCuenta) {
    this.codigoCuenta = codigoCuenta;
  }
//Método para obtener el nombre del propietario de la cuenta
  public String getNombreCuenta() {
    return nombreCuenta;
  }
//Método para setear el nombre del propietario de la cuenta
  public void setNombreCuenta(String nombreCuenta) {
    this.nombreCuenta = nombreCuenta;
  }
//Método para obtener el código del asociado
  public int getCodigoCliente() {
    return codigoCliente;
  }
//Método para setear el código del asociado
  public void setCodigoCliente(int codigoCliente) {
    this.codigoCliente = codigoCliente;
  }
//Método para obtener el token dinero
  public Double getDinero() {
    return pisto;
  }
//Método para setear el token dinero
  public void setDinero(Double dinero) {
    if(dinero > this.pisto) depositos++;
    if(dinero < this.pisto) retiros++;
    this.pisto = dinero;
  }
//Método de bandera para obtener y validación de tipo de moneda
  public Boolean getQuetzales() {
    return quetzales;
  }
//Método de bandera para setear y validación de tipo de moneda
  public void setQuetzales(Boolean quetzales) {
    this.quetzales = quetzales;
  }
//Método para obtener la fecha del depósito
  public LocalDate getFehcaDeposito() {
    return fechaDeposito;
  }
//Método para setear la fecha del depósito
  public void setFehcaDeposito(LocalDate fechaDeposito) {
    this.fechaDeposito = fechaDeposito;
  }
//Hacemos público nuestro método
  public LocalDate getFechaDeposito() {
    return fechaDeposito;
  }
//Hacemos público nuestro método para obtener retiros
  public int getRetiros() {
    return retiros;
  }
//Hacemos público nuestro método para obtener depósitos
  public int getDepositos() {
    return depositos;
  }   
}
