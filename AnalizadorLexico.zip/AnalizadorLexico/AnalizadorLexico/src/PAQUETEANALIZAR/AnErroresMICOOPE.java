package PAQUETEANALIZAR;

import java.time.LocalDate;

public class AnErroresMICOOPE {

  private int noLinea = 0;

  //Declaración de método para posibles errores a encontrar
  public Transaccion analizarLinea(String linea) {
    noLinea++;
    int posStartParen = linea.indexOf('(');
    int posEndParen = linea.indexOf(')');

    if (posStartParen < 0 || posEndParen < 0 || posStartParen > posEndParen) {
    	System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.err.println("Error Linea #" + noLinea + "." + linea);
      System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      return new Transaccion(Ejecucion.ERROR, null);
    }

    String accionS = linea.substring(0, posStartParen);
    Ejecucion accion = getAccion(accionS);
    if (accion == Ejecucion.ERROR) {
    	System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.err.println("Error Linea #" + noLinea + ". Funcion incorrecta");
      System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      return new Transaccion(Ejecucion.ERROR, null);
    }

    String parametros = linea.substring(posStartParen + 1, posEndParen);
    String[] params = parametros.split(",");

    if (params.length != accion.getNoParametros()) {
    	System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      System.err.println("Error Linea #" + noLinea + ". Parametros incorrectos");
      System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      return new Transaccion(Ejecucion.ERROR, null);
    }
    String[] tipos = accion.getTipoParametros();
    Object[] pa = new Object[tipos.length];
    for (int i = 0; i < tipos.length; i++) {
      try {
        Object newObj = null;
        if (tipos[i].equals("Integer")) {
          newObj = Integer.valueOf(params[i]);
        }
        if (tipos[i].equals("String")) {
          newObj = params[i];
        }
        if (tipos[i].equals("Date")) {
          String d = params[i].replaceAll("\"", "");
          String[] sd = d.split("/");
          d = sd[2] + "-" + sd[1] + "-" + sd[0];
          newObj = LocalDate.parse(d);
        }
        if (tipos[i].equals("Double")) {
          newObj = Double.valueOf(params[i]);
        }
        if (tipos[i].equals("Boolean")) {
          newObj = params[i].equals("true");
        }
        pa[i] = newObj;
      } catch (Exception e) {
        System.out.println("Error de cast");
        return new Transaccion(Ejecucion.ERROR, null);
      }
    }

    return new Transaccion(accion, pa);
  }

  public Ejecucion getAccion(String accion) {
    return Ejecucion.getAccion(accion);
  }
}